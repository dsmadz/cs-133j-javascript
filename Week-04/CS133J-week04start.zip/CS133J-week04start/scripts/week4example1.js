/*
Program:	Week 4 Example 1
Author:		Debra & CS 133S Students
Date:		1/27/2020
Desc:		Demonstrating use of functions
*/

//constant declarations
const WIDGET_PRICE = .1;
const GADGET_PRICE = .25;
const THING_PRICE = 1000000;

window.onload = function() {
	//calculate comm when rate changes
	$("theRate").onchange = function() {
		$("theCommission").innerHTML = "$" + commCalc($("theRate").value, $("theSales").value);
	}
	
	//calculate subtotals as users enter new values in textboxes
	$("txtWidgetQty").oninput = function() {
		
	}
	
	$("txtGadgetQty").oninput = function() {
		
	}
	
	$("txtThingQty").oninput = function() {
		
	}
}


/*---------------------------------------------------------------------------
Name: $
Desc: shortcut to prevent typing window.document.getElementById all the time
Args: theId (string) - the particular id value of the HTML element targeted
Retn: (object reference) - the object reference that matches theId value
---------------------------------------------------------------------------*/
function $(theId) {
	return window.document.getElementById(theId);
}

/*---------------------------------------------------------------------------
Name: commCalc
Desc: calculate a commission
Args: commRate - commission % (aka rate)
      sales
Retn: commTotal - dollar amount/commission total
---------------------------------------------------------------------------*/
function commCalc(commRate, sales) {
	var commTotal = commRate * sales;
	return commTotal.toFixed(2);
}

/*---------------------------------------------------------------------------
Name: subTotal
Desc: calculate subtotal based on quantity & price
Args: quantity
	  price
Retn: total
---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------
Name: chooseMsg
Desc: pick an inspiration message for salespeople based on sales
Args: sales
Retn: theMsg
---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------
Name: dailyGtg
Desc: select a daily greeting based on day of the week
Args: none
Retn: theGtg
---------------------------------------------------------------------------*/








