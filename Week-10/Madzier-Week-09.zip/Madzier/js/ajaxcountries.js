/**********************************
@auth   Doug Madzier
@date   Thu, March 14, 2024
@class  CS133J Week-09 Homework 08
***********************************/

window.onload = function () {
    const selContinents = document.querySelectorAll("#selContinents li a");
    for (selCont of selContinents) {
        selCont.addEventListener("click", evtFunc);
    }

}
/***************************************
 * @name    evtFunc
 * @desc    Assigns event target to variable for ajax request and prevents default action for <a>.
 * @param   evt
 * @retrn   none
 * @calls   getContinentInfo()
 ***************************************/
function evtFunc(evt) {
    const selContinents = evt.currentTarget.innerText;
    evt.preventDefault();
    getContinentInfo(selContinents)
}
/***************************************
 * @name    getContinentInfo
 * @desc    XHR ajax request.
 * @param   myContinent
 * @retrn   none
 * @calls   displayInfo()
 ***************************************/
function getContinentInfo(selContinents){
    let myReq = new XMLHttpRequest; 

	myReq.open("GET", "country.php?selContinent=" + selContinents, true);
	myReq.send();

    myReq.onreadystatechange = function() {
		if(this.readyState == 4 && this.status == 200) {
			//4. Process the response text as desired
            const myContinent = JSON.parse(this.responseText);
            console.log("My cont ", this.responseText);
            // Call displayInfo() function.
			displayInfo(myContinent)
		}
    }
}
/***************************************
 * @name    displayInfo
 * @desc    Formats and displays results.
 * @param   myContinent
 * @retrn   none
 ***************************************/
function displayInfo(myContinent){
    // Clear previous search if any.
    $("output").innerHTML = "";
    for(let i = 0; i < myContinent.length; i++) {
        let myDiv = document.createElement("div");
        myDiv.classList.add("country");
        let myH3 = document.createElement("h3");
        let myUl = document.createElement("ul");
        let myH3Text = document.createTextNode(myContinent[i].name);
        // Append  data
        myH3.append(myH3Text);
        myDiv.append(myH3);
        myUl.innerHTML += '<li>Population: ' + myContinent[i].population + '</li>';
        myUl.innerHTML += '<li>GNP: ' + myContinent[i].gnp + '</li>';
        myUl.innerHTML += '<li>Surface Area: ' + myContinent[i].surfaceArea + '</li>';
        myUl.innerHTML += '<li>Life Expectncy: ' + myContinent[i].lifeExpectancy + '</li>';
        myDiv.append(myUl);
        // Print data to html.
        $("output").append(myDiv);
    }
   
}

/***********************************************
*@name   $
*@desc   Returns element ID
*@param  getId
*@retrn  window.document.getElementById(getId);
************************************************/
const $ = (getId) => {
    return window.document.getElementById(getId);
}